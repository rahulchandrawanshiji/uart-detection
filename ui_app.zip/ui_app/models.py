from django.db import models
from django.utils.html import mark_safe
from django.utils.timezone import now

class DetectedImage(models.Model):
    id = models.BigAutoField(primary_key=True) 
    image_path = models.CharField(max_length=255)
    detected_objects = models.TextField()
    head_count = models.IntegerField(default=0)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.detected_objects} - {self.timestamp.strftime('%Y-%m-%d %H:%M:%S')}"

    def image_tag(self):
        return mark_safe(f'<img src="/{self.image_path}" width="150" />')

    image_tag.short_description = 'Preview'

class SensorData(models.Model):
    # Define fields as per your requirements
    id = models.BigAutoField(primary_key=True)
    sensor = models.CharField(max_length=255)
    min_value = models.FloatField()
    max_value = models.FloatField()
    start = models.BooleanField(default=False)
    end = models.BooleanField(default=False)
    auto = models.BooleanField(default=False)
    auto_interval = models.IntegerField()
    event_interval = models.IntegerField()

    def __str__(self):
        return f"Sensor: {self.sensor}, Min: {self.min_value}, Max: {self.max_value}"
    
class UartData(models.Model):
    IAQ = models.IntegerField()
    PM2_5 = models.IntegerField()
    PM10 = models.IntegerField()
    CO2 = models.IntegerField()
    TVOC_Value = models.IntegerField()
    TVOC_Index = models.IntegerField()
    Viral_Value = models.IntegerField()
    Viral_Index = models.IntegerField()
    Humidity = models.IntegerField()
    Temperature_C = models.IntegerField()
    Temperature_F = models.IntegerField()
    PM1 = models.IntegerField()
    timestamp = models.DateTimeField(default=now)

    def __str__(self):
        return f"IAQ: {self.IAQ}, PM2_5: {self.PM2_5}, Temperature_C: {self.Temperature_C}"